<h4 class="mx-4"><?= $penyanyi ?> - <?= $judul ?></h4>
<audio controls autoplay>
  <source src="lagu/<?= $lagu ?>" type="audio/mpeg">
</audio>