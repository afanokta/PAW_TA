<nav class="navbar navbar-expand navbar-light my-navbar ">

  <!-- Sidebar Toggle (Topbar) -->
  <div type="button" id="bar" class="nav-icon1 hamburger animated fadeInLeft is-closed" data-toggle="offcanvas">
    <span></span>
    <span></span>
    <span></span>
  </div>


  <!-- Topbar Search -->
  <input type="text" class="form-control bg-light " name="input" id="search" placeholder="Search for..." aria-label="Search">
  <ul class="navbar-nav ml-auto mr-4">
    <li class="">
      <a href="/logout" class="fw-bold btn btn-danger mx-4">
        <p class="text-white p-0 m-0">Logout</p>
      </a>
    </li>
  </ul>

</nav>