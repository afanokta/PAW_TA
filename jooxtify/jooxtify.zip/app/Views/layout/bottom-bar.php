<nav class="navbar navbar-expand navbar-light my-navbar m-0 p-4 fixed-bottom justify-content-center" id="setplay">
  
</nav>